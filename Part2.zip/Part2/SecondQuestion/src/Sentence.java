
import java.util.ArrayList;
//I was organizing my object-oriented concept. I decided that sentence-word is a composition relationship. 
//All sentences have words. == the principle of Composition

public class Sentence {

	private String sentenceName = ""; // sentenceName is basically a sentence within a String format
	private ArrayList<Word> wordList; // because all sentences are created with
										// words, I created a wordList for
										// Sentence class
	// Constructor of Sentence class
	public Sentence() {
		wordList = new ArrayList<Word>(); //composition
	}

	// get Method for wordList
	public ArrayList<Word> getWordList() {
		return wordList;
	}

	// set Method for wordList
	public void setWordList(ArrayList<Word> wordList) {
		this.wordList = wordList;
	}

	// this function is created for assigning string type words to the word
	// objects.
	// and then I add this word objects to the wordList array => a field of
	// Sentence class.
	public void addToWordList(String newWord) {
		Word tempWord = new Word();
		tempWord.setName(newWord);
		wordList.add(tempWord);
	}

	// print function for Sentence objects.
	public void printWordArrayList() {
		if (wordList.size() > 0) {
			for (int i = 0; i < wordList.size(); i++) {
				wordList.get(i).printWord();
			}
		}
	}

	// setters and getters for the Sentence ;
	public String getSentenceName() {
		return sentenceName;
	}

	public void setSentenceName(String sentenceName) {

		this.sentenceName = sentenceName;
	}

	public int sentenceLength() {
		String[] words = this.sentenceName.split("\\s+");

		return words.length;

	}

	public void printSentence() {
		System.out.println(this.getSentenceName());
	}

}
