public class Word {
	// I was organizing my object-oriented concept. I decided that sentence-word
	// is a composition relationship.
	// All sentences have words. == the principle of Composition

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void printWord() {
		System.out.println(this.getName());
	}
}
