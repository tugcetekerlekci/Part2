
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		/*
		 * The reason of I used ArrayLists; Array lists manage arrays
		 * internally, traversing in array is very fast. getting a particular
		 * item is very fast. ..position in memory in item is fast. Because I was need to
		 * manage elements internally and traversing was necessary to find elements, I preferred Arraylists. 
		 */

		File file = new File("nlp_data.txt");
		File file2 = new File("NER.txt");
		BufferedReader br = null; //
		BufferedReader br2 = null;
		ArrayList<String> quoteList = new ArrayList<String>(); // List of
																// strings. At
																// the end of
																// the program
																// it will hold
		// all the words as an element without their punctuation marks.
		// * Hypothetic example : [First, Word War,started,today]
		ArrayList<Word> words = new ArrayList<Word>(); // List of word objects.
		// the Word ArrayList that hold words as word objects.
		ArrayList<String> wordList = new ArrayList<String>();
		/* wordList includes strings that are in the line */
		/*
		 * At the end of the program wordList will include all the words in txt
		 * file with their punctuation marks. Hypothetic example : [
		 * "First, Word War",started,today.]
		 * 
		 */

		ArrayList<Sentence> sentenceList = new ArrayList<Sentence>();
		// this Sentence ArrayList is for including sentences as elements.
		// example: [Today is rainy. , Tomorrow will be better.]
		ArrayList<Word> wordNER = new ArrayList<Word>();
		// Word objects for NER.txt file; All words in NER.txt are included to
		// wordNER as words.
		try {

			// reading the "nlp_data.txt" file
			FileReader fr = new FileReader(file);
			br = new BufferedReader(fr);
			String line; // get the lines of the txt file

			while ((line = br.readLine()) != null) {

				int quoteCount = line.length() - line.replaceAll(" ", "").length();
				// this line calculates how many words in the line.

				String[] firstDivide = new String[quoteCount + 1]; // getting an
																	// Array
																	// according
																	// to size
																	// of the
																	// line

				for (int i = 0; i <= quoteCount; i++) {

					firstDivide = line.split(" "); // split the elements of the
													// array

					Word word = new Word(); // the word objects is for holding
											// arrays.
					word.setName(firstDivide[i]); // each String became a name
													// of word object.
					quoteList.add(word.getName());
					wordList.add(word.getName());

				}

				cleanWord(quoteList); // cleanWord function basically get rid of
										// the punctuation marks. Words become
										// clean
				// ["the,, "world."] becomes => [the,world]
			}

			// this forloop adds the string words ,which is in quoteList, to the
			// word objects as the names of word objects.
			// with that way, I can hold the words as a word objects.
			// and I can use getter setters and print methods which belongs to
			// Word class.
			for (int k = 0; k < quoteList.size(); k++) {
				Word word = new Word();
				word.setName(quoteList.get(k)); // sets the list elements as a
												// name of word object.
				words.add(word); // add this word object to the Word ArrayList
				// System.out.println(words.get(k).getName());

			}

			// to create an a sentence I thought that punctuation is the key
			// factor.
			// I traverse the arrayList to control if any punctuation symbol
			// occurs.Like (.?!)
			// I saw there is ... in the sentence however it was not the end of
			// the sentence.
			// For this reason I decided to put another control to check if this
			// is a sentence or not.
			// If punctuation symbol occurs, it will be sign that this can be
			// the end of the sentence.
			// then, I control if the first character of the element of the
			// punctuation symbol's is lower case or not.
			// I can check also if it is uppercase or not. Actually I just want
			// to learn if it is a letter.
			// When ... comes, program controls the last dot and then will check
			// the first dot
			// the first dot is not a lower case; So program will understand
			// this is not the end of the sentence.
			// I will assign all the words before this punctuation symbol as a
			// sentence.
			// and I create a Sentence array.
			String tempSentence = "";
			ArrayList<String> tempWordArrayList = new ArrayList<String>();
			for (int i = 0; i < wordList.size(); i++) { // controls all the
														// wordList.
				Sentence newSentence = new Sentence(); // create a sentence
														// object
				String temp = wordList.get(i); // getting the String at index i
												// and hold it at temp
				if (temp.contains(".") || temp.contains("?") || temp.contains("!")) {
					if (Character.isLowerCase(temp.charAt(0))) { // check if the
																	// string a
																	// real word
																	// or not

						tempSentence += temp; // adding the words before the
												// punction symbol to create a
												// sentence

						newSentence.setSentenceName(tempSentence); // the
																	// sentence
																	// is added
																	// to the
																	// newSentence
																	// object/
						/*
						 * (It provided all the conditions )
						 * 
						 */

						for (int k = 0; k < tempWordArrayList.size(); k++) {
							newSentence.addToWordList(tempWordArrayList.get(k));
						}

						newSentence.addToWordList(temp);

						tempWordArrayList.clear(); // clear the tempArray list
													// for the next sentence.

						sentenceList.add(newSentence); // add newSentence to a
														// sentenceList

						tempSentence = ""; // make empty the tempSentence for
											// next sentence

					}
				} else {
					tempSentence += temp + " "; // adding the words before the
												// punctuation symbol to create
												// a sentence
					newSentence.addToWordList(temp); // adding the words until
														// the sentence ends to
														// the word array list
														// in Sentence class

					tempWordArrayList.add(temp);
				}

			}

			/////// ============= Reading NER.txt file
			/////// NER.txt====================/////////////////////////////////////////
			FileReader fr2 = new FileReader(file2);
			br2 = new BufferedReader(fr2);
			String line2;

			while ((line2 = br2.readLine()) != null) {
				line2 = line2.trim(); //
				Word word = new Word();
				// System.out.println(line2);
				word.setName(line2);
				wordNER.add(word);

			}

		} catch (FileNotFoundException e) {
			System.out.println("File not found " + file.toString());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Unable to read file" + file.toString());
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NullPointerException e) {
				// The file was probably never opened...
				System.out.println("The file was never opened...");

			}

		}
		/* why did I choose Linear Search? 
		 * For small lists of unordered elements, linear search is easy to implement and 
		 * reasonably efficient. I thought it is simpler approach, simple and less code
		 * The worst case is when we search for an item not in the list, 
		 * since program must inspect every element in the list. 
		 * The complexity of my search is O(N2)
		 * */
		//This is my linear search algorithm;
		int k = 0;
		for (int i = 0; i < sentenceList.size(); i++) {
			Sentence tempSentence = sentenceList.get(i);

			k = i + 1; // holds the sentence order..
			for (int j = 0; j < wordNER.size(); j++) {
				if (!wordNER.get(j).getName().equals("")
						&& tempSentence.getSentenceName().contains(wordNER.get(j).getName())) {
					System.out.println(wordNER.get(j).getName() + " is found at " + k + "th sentence");
				}
			}

		}
	}

	static ArrayList<String> cleanWord(ArrayList<String> quoteList) {

		for (int i = 0; i < quoteList.size(); i++) {

			if (quoteList.get(i).contains("?")) {
				String temp = quoteList.get(i);
				quoteList.set(i, temp.replace("?", ""));
			}

			if (quoteList.get(i).contains(",")) {
				String temp = quoteList.get(i);
				quoteList.set(i, temp.replace(",", ""));
			}

			if (quoteList.get(i).contains("...")) {
				String temp = quoteList.get(i);
				quoteList.set(i, temp.replace("...", ""));
			}

			if (quoteList.get(i).contains("\'")) {
				String temp = quoteList.get(i);
				quoteList.set(i, temp.replace("\'", ""));
			}

			if (quoteList.get(i).contains("\"")) {
				String temp = quoteList.get(i);
				quoteList.set(i, temp.replace("\"", ""));
			}

			if (quoteList.get(i).contains("(")) {
				String temp = quoteList.get(i);
				quoteList.set(i, temp.replace("(", ""));
			}

			if (quoteList.get(i).contains(")")) {
				String temp = quoteList.get(i);
				quoteList.set(i, temp.replace(")", ""));
			}

			if (quoteList.get(i).contains(".")) {
				String temp = quoteList.get(i);
				quoteList.set(i, temp.replace(".", ""));
			}
			if (quoteList.get(i).contains("n;")) {
				String temp = quoteList.get(i);
				quoteList.set(i, temp.replace("n;", ""));
			}

		}

		return quoteList;
	}

}
